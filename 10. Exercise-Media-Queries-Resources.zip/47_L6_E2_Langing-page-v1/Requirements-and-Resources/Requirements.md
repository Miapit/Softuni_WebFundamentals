# 02. Purple Spiders

## Tasks
* Create an **"index.html"** file with title - **"Purple Spiders Agency"**
* Get the latest reset css
* Get the latest typography css
* Get the latest buttons css
* Get the latest forms css
* Create a section with a title "Need a website"
* Create a section with a title "Our Team"
* Create a section with a title "Sign-up to our Newsletter"
* Create a section with a title "Testimonials"
* Create footer
* Make the page responsive per the screenshots attached
